package egov.border.service;

import java.util.HashMap;

public interface BorderService {
	public void insertBorder(HashMap<String, Object> paramMap) throws Exception;
	public HashMap<String, Object> selectBorder(HashMap<String, Object> paramMap) throws Exception;
	public HashMap<String, Object> selectBorderView(HashMap<String, Object> paramMap) throws Exception;
	public void insertBorderReply(HashMap<String, Object> paramMap) throws Exception;
	public void updateBorderEdit(HashMap<String, Object> paramMap)throws Exception;
	public void updateBorderRemove(HashMap<String, Object> paramMap)throws Exception;
}
