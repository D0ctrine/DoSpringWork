package egov.main.service.impl;

import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.main.service.MainService;
import egov.web.dao.MainDAO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;


@Service("MainService")
public class MainServiceImpl extends EgovAbstractServiceImpl implements MainService{

	@Resource(name="MainDAO")MainDAO mainDAO;
	
	@Override
	public HashMap<String, Object> selectMain(HashMap<String, Object> paramMap) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("진입성공2");
		return mainDAO.selectMain(paramMap);
	}

	@Override
	public HashMap<String, Object> selectLogin(HashMap<String, Object> paramMap) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("진입성공3");
		return mainDAO.selectLogin(paramMap);
	}

	@Override
	public HashMap<String, Object> selectLogin2(HashMap<String, Object> paramMap) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("진입성공4");
		return mainDAO.selectLogin2(paramMap);
	}

}
