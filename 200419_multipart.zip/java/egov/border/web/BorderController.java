package egov.border.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import egov.border.service.BorderService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class BorderController {

	private static final Logger logger = LoggerFactory.getLogger(BorderController.class);

	@Resource(name = "BorderService")
	BorderService borderService;

	@Resource(name = "fileUploadProperty")
	Properties fileUploadProperty;

	@RequestMapping(value = "/borderInsert.do")
	public String borderInsert(HttpServletRequest request, ModelMap model) throws Exception {
		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		String title = request.getParameter("title").toString();
		String mytextarea = request.getParameter("mytextarea").toString();

		String userId = "";
		// javascript로 검증 후 서버에서 재 검증
		// 몇몇 검증을 더 추가해줘야합니다.

		if (title.length() > 15) {
			return "redirect:/borderWrite.do";
		} else if (mytextarea.length() > 2000) {
			return "redirect:/borderWrite.do";
		} else if (request.getSession().getAttribute("USER_ID") == null) {
			// session안에 VO또는 DTO(회원 클래스의 객체)를 저장해두고 사용할 수 도 있습니다.
			request.getSession().invalidate();
			return "redirect:/login.do";
		} else {
			userId = request.getSession().getAttribute("USER_ID").toString();

			paramMap.put("userId", userId);
			paramMap.put("userIp", request.getRemoteAddr());
			paramMap.put("title", title);
			paramMap.put("mytextarea", mytextarea);
		}

		String convertuid = "";
		String uploadPath = fileUploadProperty.getProperty("file.uploadborderImg.path");
		String originalEx = "";
		String filePath = "";
		if (request instanceof MultipartHttpServletRequest) {
			final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
			final Map<String, MultipartFile> files = multiRequest.getFileMap();
			File saveFolder = new File(uploadPath);
			if (!saveFolder.exists() || saveFolder.isFile()) {
				saveFolder.mkdirs();
			}

			Iterator<Entry<String, MultipartFile>> itr = files.entrySet().iterator();
			MultipartFile file;

			/* 반복해서 파일을 읽어들인다. */
			while (itr.hasNext()) {
				Entry<String, MultipartFile> entry = itr.next();
				file = entry.getValue();
				if (!"".equals(file.getOriginalFilename())) {
					// 서버 호스팅업체(cafe24,통큰아이) / 네트워크 자원 S 10MB 이미지 파일용량 되도록 압축
					int filesize = (int) file.getSize();
					int maxSize = 1 * 1024 * 1024;// 1MB
					if (filesize > maxSize) {
						return "redirect:/borderWrite.do";
					}
					Calendar cal = Calendar.getInstance();
					int year = cal.get(Calendar.YEAR);
					int month = cal.get(Calendar.MONTH) + 1;
					int date = cal.get(Calendar.DATE);
					int hour = cal.get(Calendar.HOUR_OF_DAY);
					// 서버의 저장할 파일이름
					convertuid = UUID.randomUUID().toString().replace("-", "") + year + month + date + hour;
					originalEx = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
					/* 특정 확장자만 원할경우 확장자 체크추가. */
					/* 보안적인 요소를 더 추가가능. */
					/* 보안업체 api사용으로 바이러스검사. */
					/* 실 서버에서 보안업체의 폴더검사. */
					/* 이미지파일일 시 이미지압축. */
					convertuid = convertuid + "." + originalEx;
					filePath = uploadPath + convertuid;
					file.transferTo(new File(filePath.replaceAll(" ", "")));
				}
			}
		}
		paramMap.put("filename", convertuid);
		paramMap.put("filetype", originalEx);
		// 자신의 포트에 맞게 변경필요.
		paramMap.put("fileurl", "http://localhost:8080/test01/borderView/image.do?file=" + convertuid);
		borderService.insertBorder(paramMap);
		return "redirect:/borderList.do";
	}

	// ResponseEntity<byte[]>대신에 AbstractView방법도 있습니다.
	@RequestMapping(value = "/borderView/image.do")
	public ResponseEntity<byte[]> imageshow(HttpServletRequest request, ModelMap model) throws Exception {
		request.setCharacterEncoding("UTF-8");

		String fileName = "";
		fileName = request.getParameter("file").toString();

		String uploadPath = fileUploadProperty.getProperty("file.uploadborderImg.path");

		InputStream in = null;
		ResponseEntity<byte[]> entity = null;

		if (fileName.equals("") || fileName == null) {
			return null;
		}
		try {
			/* 요청된 확장자를 제한할 수 있습니다. virustotal api*/
			/* 보안적인 요소를 더 추가할 수 있습니다. */
			/* 대용량을 다운로드 내보낼시 속도제어가 필요합니다. */
			HttpHeaders headers = new HttpHeaders();
			in = new FileInputStream(uploadPath + fileName);
			// 알려지지 않은 파일 타입.
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			headers.add("Content-Disposition",
					"attatchment; filename=\"" + new String(fileName.getBytes("UTF-8"), "ISO-8859-1") + "\"");
			entity = new ResponseEntity<byte[]>(IOUtils.toByteArray(in), headers, HttpStatus.CREATED);
		} catch (Exception e) {
			e.printStackTrace();
			entity = new ResponseEntity<byte[]>(HttpStatus.BAD_REQUEST);
		} finally {
			in.close();
		}

		return entity;
	}

	@RequestMapping(value = "/borderWrite.do")
	public String borderWrite(HttpServletRequest request, Model model) {
		String userId = "";
		// 권한 검사도 가능.
		if (request.getSession().getAttribute("USER_ID") == null) {
			request.getSession().invalidate();
			return "redirect:/login.do";
		} else {
			userId = request.getSession().getAttribute("USER_ID").toString();
		}

		model.addAttribute("userId", userId);

		return "border/borderwrite";
	}

	@RequestMapping(value = "/borderList.do")
	public String borderList(HttpServletRequest request, ModelMap model) throws Exception {
		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("ref_cursor", null);

		// Start페이징처리
		String pageNo = "";
		pageNo = request.getParameter("pageNo");
		if (pageNo == null || pageNo.equals("")) {
			pageNo = "1";
		}
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(Integer.parseInt(pageNo)); // 현재 페이지 번호
		paginationInfo.setRecordCountPerPage(10); // 한 페이지에 게시되는 게시물 건수
		paginationInfo.setPageSize(10); // 페이징 리스트의 사이즈ex:10입력<1>~<10>

		int currentPageNo = paginationInfo.getCurrentPageNo();// 현재페이지번호
		int recordCountPerPage = paginationInfo.getRecordCountPerPage(); //// 한 페이지에 게시되는 게시물 건수

		paramMap.put("currentPageNo", currentPageNo);
		paramMap.put("recordCountPerPage", recordCountPerPage);
		System.out.println("DB 곧 시작할예정");
		borderService.selectBorder(paramMap);
		System.out.println("DB 끝났어유");
		int listcount = 0;
		listcount = Integer.parseInt(paramMap.get("list_count").toString());
		paginationInfo.setTotalRecordCount(listcount); // 전체 게시물 건 수
		// End페이징처리
		list = (ArrayList<HashMap<String, Object>>) paramMap.get("ref_cursor");
		model.addAttribute("borderlist", list);
		model.addAttribute("paginationInfo", paginationInfo);
		model.addAttribute("pageNo", pageNo);

		return "border/BorderList";
	}

	@RequestMapping(value = "/borderView.do")
	public String borderView(HttpServletRequest request, ModelMap model) throws Exception {
		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		ArrayList<HashMap<String, Object>> resultList = new ArrayList<HashMap<String, Object>>();

		String no = request.getParameter("no").toString();
		paramMap.put("borderId", no);
		paramMap.put("ref_cursor", null);
		System.out.println("db한다 오바여");
		borderService.selectBorderView(paramMap);
		System.out.println("db끝");
		resultList = (ArrayList<HashMap<String, Object>>) paramMap.get("ref_cursor");
		if (request.getSession().getAttribute("USER_ID") == null) {
			model.addAttribute("userId", request.getSession().getAttribute("USER_ID").toString());

		} else {
			model.addAttribute("userId", request.getSession().getAttribute("USER_ID").toString());
		}

		model.addAttribute("resultList", resultList);
		return "border/borderview";
	}

	@RequestMapping(value = "/borderReply.do")
	public String borderReply(HttpServletRequest request, ModelMap model) throws Exception {
		String userId = "";
		if (request.getSession().getAttribute("USER_ID") == null) {
			request.getSession().invalidate();
			return "redirect:/login.do";
		} else {
			userId = request.getSession().getAttribute("USER_ID").toString();
		}
		model.addAttribute("userId", userId);
		String borderId = request.getParameter("no").toString();
		model.addAttribute("borderId", borderId);

		return "border/borderreply";
	}

	@RequestMapping(value = "/borderReplyReq.do")
	public String borderReplyReq(HttpServletRequest request, ModelMap model) throws Exception {
		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		String title = request.getParameter("title").toString();
		String mytextarea = request.getParameter("mytextarea").toString();

		String userId = "";
		String originalId = "";

		// javascript로 검증 후 서버에서 재 검증
		// 몇몇 검증을 더 추가해줘야합니다.

		if (title.length() > 15) {
			return "redirect:/borderList.do";
		} else if (mytextarea.length() > 2000) {
			return "redirect:/borderList.do";
		} else if (request.getSession().getAttribute("USER_ID") == null) {
			// session안에 VO또는 DTO(회원 클래스의 객체)를 저장해두고 사용할 수 도 있습니다.
			request.getSession().invalidate();
			return "redirect:/login.do";
		} else {
			userId = request.getSession().getAttribute("USER_ID").toString();
			originalId = request.getParameter("originalId").toString();

			paramMap.put("originalId", originalId);
			paramMap.put("userId", userId);
			paramMap.put("userIp", request.getRemoteAddr());
			paramMap.put("title", title);
			paramMap.put("mytextarea", mytextarea);
		}

		borderService.insertBorderReply(paramMap);
		System.out.println("실행했다구");
		return "redirect:/borderList.do";
	}

	@RequestMapping(value = "/borderEdit.do")
	public String borderEdit(HttpServletRequest request, ModelMap model) throws Exception {
		String userId = "";
		if (request.getSession().getAttribute("USER_ID") == null) {
			request.getSession().invalidate();
			return "redirect:/login.do";
		} else {
			userId = request.getSession().getAttribute("USER_ID").toString();
		}
		model.addAttribute("userId", userId);
		String borderId = request.getParameter("no").toString();
		model.addAttribute("borderId", borderId);
		// 변경전 제목,내용 보여주기 로직추가하실 수 있습니다..
		return "border/borderedit";
	}

	@RequestMapping(value = "/borderEditReq.do")
	public String borderEditReq(HttpServletRequest request, ModelMap model) throws Exception {
		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		String title = request.getParameter("title").toString();
		String mytextarea = request.getParameter("mytextarea").toString();
		String userId = "";
		String originalId = "";
		// javascript로 검증 후 서버에서 재 검증
		// 몇몇 검증을 더 추가해줘야합니다.
		if (title.length() > 15) {
			return "redirect:/borderList.do";
		} else if (mytextarea.length() > 2000) {
			return "redirect:/borderList.do";
		} else if (request.getSession().getAttribute("USER_ID") == null) {
			// session안에 VO또는 DTO(회원 클래스의 객체)를 저장해두고 사용할 수 도 있습니다.
			request.getSession().invalidate();
			return "redirect:/login.do";
		} else {
			originalId = request.getParameter("originalId").toString();
			userId = request.getSession().getAttribute("USER_ID").toString();
			paramMap.put("originalId", originalId);
			paramMap.put("userId", userId);
			paramMap.put("userIp", request.getRemoteAddr());
			paramMap.put("title", title);
			paramMap.put("mytextarea", mytextarea);
		}
		borderService.updateBorderEdit(paramMap);
		return "redirect:/borderList.do";
	}

	@RequestMapping(value = "/borderRemove.do")
	public String borderRemove(HttpServletRequest request, ModelMap model) throws Exception {
		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		String originalId = "";
		String userId = "";
		if (request.getSession().getAttribute("USER_ID") == null) {
			// session안에 VO또는 DTO(회원 클래스의 객체)를 저장해두고 사용할 수 도 있습니다.
			request.getSession().invalidate();
			return "redirect:/login.do";
		} else {
			originalId = request.getParameter("no").toString();
			userId = request.getSession().getAttribute("USER_ID").toString();
			paramMap.put("originalId", originalId);
			paramMap.put("userId", userId);
			paramMap.put("userIp", request.getRemoteAddr());
		}
		borderService.updateBorderRemove(paramMap);
		// 프로시저에 ID가 일치하는지에대한 로직 필요하다고 명시해주기.
		// 프로시저DAO.XML생성할차례+프로시저생성필요.
		return "redirect:/borderList.do";
	}

}
