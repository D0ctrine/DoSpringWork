package egov.border.dao;

import java.util.ArrayList;
import java.util.HashMap;

import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper(value="BorderDAO")
public interface BorderDAO {
	
	void insertBoard(HashMap<String, Object> paramMap) throws Exception ;
	HashMap<String, Object> selectBorder(HashMap<String, Object> paramMap) throws Exception;
	HashMap<String, Object> selectBorderView(HashMap<String, Object> paramMap) throws Exception;
	void insertBorderReply(HashMap<String, Object> paramMap) throws Exception;
	void updateBorderEdit(HashMap<String, Object> paramMap) throws Exception;
	void updateBorderRemove(HashMap<String, Object> paramMap)throws Exception;
}
