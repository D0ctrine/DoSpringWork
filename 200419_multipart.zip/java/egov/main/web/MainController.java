package egov.main.web;

import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.main.service.MainService;
import egov.web.dao.MainDAO;

@Controller
public class MainController {

	private static final Logger logger = LoggerFactory.getLogger(MainController.class);
	
	@Resource(name="MainService") MainService mainService;
	
	@RequestMapping(value = "/main.do")
	public String main(HttpServletRequest request, Model model) {

		return "main/main";
	}

	@RequestMapping(value = "/main2.do")
	public String main2(HttpServletRequest request, Model model) {
		return "main/main2";
	}

	@RequestMapping(value = "/main3.do")
	public String main3(@RequestParam("pw") String pw,HttpServletRequest request, Model model) {
		String id = request.getParameter("id").toString();
		int userNo = Integer.parseInt(request.getParameter("userNo"));
		if (id.equals("asdqwe")) {
			model.addAttribute("userid", pw);
		} else {
			model.addAttribute("userid", pw);
		}
		
		userNo= userNo+5;
		model.addAttribute("userNo",userNo);
		

		return "main/main3";
	}
	
	@RequestMapping(value = "/main4/{userNo}.do")
	public String main4(@PathVariable String userNo,HttpServletRequest request, Model model) {
		model.addAttribute("userNo",userNo);
		
		return "main/main3";
	}
	
	@RequestMapping(value = "/main5.do")
	public String main5(HttpServletRequest request, Model model) throws Exception {
		String userid="";
		
		//vo
		try{
		HashMap<String,Object> paramMap = new HashMap<String,Object>();
		HashMap<String,Object> resultMap = new HashMap<String,Object>();
		System.out.println("hihi");
		resultMap = mainService.selectMain(paramMap);
		System.out.println("nono");
		userid=resultMap.get("USER_ID").toString();
		model.addAttribute("serverId",userid);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return "main/main3";
	}
	
	@RequestMapping(value = "/login.do")
	public String login(HttpServletRequest request, Model model) {
		return "login/login";
	}

	@RequestMapping(value = "/loginSubmission.do")
	public String loginSubmission(HttpServletRequest request, Model model) throws Exception{
		String userId= request.getParameter("id").toString();
		if(userId.length()>10) {
			return "redirect:/login.do";
		}
			HashMap<String,Object> paramMap = new HashMap<String,Object>();
			paramMap.put("userId", userId);
			paramMap.put("ref_cursor", null);
			mainService.selectLogin2(paramMap);
			ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
			list = (ArrayList<HashMap<String,Object>>)paramMap.get("ref_cursor");
			if(list.size()==0) {
				return "redirect:/login.do"; 
			}else {
				userId = list.get(0).get("USER_ID").toString();
			}
			request.getSession().setAttribute("USER_ID", userId);
			
			logger.info("ST접속정보 기록===========");
			logger.info("유저 아이디 : "+userId+", 접속시간:");
			logger.info("ST접속정보 기록===========");
			
		return "main/main4";
	}
	
	@RequestMapping(value = "/main4.do")
	public String main4(HttpServletRequest request, Model model) {
		return "main/main4";
	}
	




	
	@RequestMapping(value = "/exception.do")
	public String exception(HttpServletRequest request, Model model)throws Exception {
		throw new Exception("사용자 임의의 에러발생");
		//return "main/main4";
	}
}
